# MovieInsight Datasets Documentation

This directory contains the datasets powering MovieInsight's recommendation engine and exploratory analysis.

## Dataset Overview

MovieInsight uses the **TMDB 5000 Movie Dataset**, widely recognized in machine learning and information retrieval benchmarks.

### Primary Files

1. **`movies.csv`** (approx. 5.7 MB, 4,803 records)
   - Contains high-level metadata for 4,803 feature films.
   - Key attributes:
     - `id`: Unique TMDB integer movie identifier.
     - `title`: Primary movie title.
     - `genres`: JSON array of genre objects (e.g., `[{"id": 28, "name": "Action"}]`).
     - `overview`: Full-text plot summary and synopsis.
     - `keywords`: JSON array of plot keywords and thematic tags.
     - `budget`: Production budget in USD.
     - `revenue`: Global box office revenue in USD.
     - `popularity`: TMDB calculated popularity index.
     - `vote_average`: User rating score (0.0 to 10.0 scale).
     - `vote_count`: Total number of user rating votes cast.
     - `release_date`: Theatrical release date (`YYYY-MM-DD`).

2. **`movies_credits.csv`** (approx. 40.0 MB, 4,803 records)
   - Contains full cast and crew credits linked by movie ID.
   - Key attributes:
     - `movie_id`: Foreign key matching `id` in `movies.csv`.
     - `title`: Movie title.
     - `cast`: JSON array of actors, characters, and billing orders.
     - `crew`: JSON array of crew members, departments, and jobs (including `Director`).

3. **`processed/`** (Generated directory, ignored by Git)
   - `processed_movies.csv`: Cleaned DataFrame containing parsed JSON arrays, computed financial metrics (`profit`, `roi`, `success`), and pre-tokenized metadata soup ready for TF-IDF vectorization.
   - Generated automatically on first application startup or by running:
     ```bash
     python scripts/run_pipeline.py
     ```

## How to Obtain the Dataset

If the CSV files are missing:
1. Visit the Kaggle TMDB 5000 Movie Dataset page: [kaggle.com/datasets/tmdb/tmdb-movie-metadata](https://www.kaggle.com/datasets/tmdb/tmdb-movie-metadata).
2. Download `tmdb_5000_movies.csv` and rename it to `movies.csv`.
3. Download `tmdb_5000_credits.csv` and rename it to `movies_credits.csv`.
4. Place both CSV files directly in this `data/` directory.

The application automatically checks for file existence on startup and returns clear instructions if files are absent.

## Licensing and Attribution

The raw data is provided courtesy of [The Movie Database (TMDb)](https://www.themoviedb.org/). The dataset is intended for research, educational, and personal non-commercial use under TMDb terms of service.
